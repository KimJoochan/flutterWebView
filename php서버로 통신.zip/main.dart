import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:image_picker/image_picker.dart';


void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: "Upload An Image to Server",
      home : HomeScreen()
    );
  }
}


class HomeScreen extends StatelessWidget {

  Future<void> _chooseImageFramGallery() async{
    final pickedFile = await ImagePicker().getImage(source: ImageSource.gallery);
    fileUpload(pickedFile);
  }
  Future<void> _chooseImageFramCamera() async{
    final pickedFile = await ImagePicker().getImage(source: ImageSource.camera);
    // 파일 경로를 통해 formData 생성
    fileUpload(pickedFile);
  }

  void fileUpload(pickedFile) async {
    if(pickedFile!=null){
      var dio = Dio();
      var formData = FormData.fromMap({
        'profile' : await MultipartFile.fromFile(pickedFile.path)
      });

      // 업로드 요청
      final response = await dio.post("http://ndapp.omnigolf.co.kr/flutter/upload_files.php?v=3", data: formData);
      print(response.statusCode);
      print(response.data);
      Map<String, dynamic> jsonArr = jsonDecode(response.data);
      print(jsonArr['path']);
      print(jsonArr['res']);

    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Upload An Image to Server'),
      ),
      body: SafeArea(
        child: Column(
            children: [
              SizedBox(height: 30,),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  RaisedButton(
                    onPressed: _chooseImageFramCamera,
                    child: Text("Camera"),
                    color: Colors.blue,
                    textColor: Colors.white,
                  ),
                  SizedBox(width: 20),
                  RaisedButton(
                    onPressed:
                    _chooseImageFramGallery,
                    child: Text("Gallery"),
                    color: Colors.blue,
                    textColor: Colors.white,
                  ),
                ],
              )

              //RaisedButton(onPressed: uploadFile,child: Text('File'),)
            ],
          ),
      ),
    );

  }
}
