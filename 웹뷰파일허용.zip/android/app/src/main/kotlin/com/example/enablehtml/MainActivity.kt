package com.example.enablehtml

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
