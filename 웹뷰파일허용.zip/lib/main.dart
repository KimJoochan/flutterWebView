import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter_webview_plugin/flutter_webview_plugin.dart';

Future main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Permission.camera.request();
  await Permission.microphone.request(); // if you need microphone permission

  runApp(MyApp());
}
class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: WebViewPlugin(),
    );
  }
}

class WebViewPlugin extends StatefulWidget {
  const WebViewPlugin({Key? key}) : super(key: key);

  @override
  _WebViewPluginState createState() => _WebViewPluginState();
}

class _WebViewPluginState extends State<WebViewPlugin> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:  SafeArea(
        child: WebviewScaffold(
          url: "https://kimjoochan.github.io/fluuterWeb/android/fileupload.html",
          withLocalStorage: true,
        ),
      ),
    )
     ;
  }
}

